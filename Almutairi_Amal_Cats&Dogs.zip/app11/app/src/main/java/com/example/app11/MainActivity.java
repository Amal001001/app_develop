package com.example.app11;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public static void main (String[]args){

        cat cat1 = new cat();
        dog dog1 = new dog();

        for (int i=0;i<cat1.catnames.length;i++){
            cat1.meow(cat1.catnames[i]);
            for (int j=0;j<dog1.dogage.length;j++){
                if (cat1.catage[i]<dog1.dogage[j]){
                    dog1.bark(dog1.dognames[j]);
                }

            }

        }
    }

}