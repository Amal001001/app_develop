package com.example.app11;

public class cat {
    public String name;
    public int age;
    int [] catage={2,3,5,4,2};

    String [] catnames={"Lili","Meep","Patchy","Furball","Snowball"};


    public static String meow(String name) {
        System.out.println( name + " : Meow");
        return name;
    }

}
