package com.example.app11;

public class dog {
    public String name;
    public int age;
    int [] dogage={4,2,6,5,3};
    String [] dognames={"Blue","Bright","Rufus","Fred","Spot"};

    public static String bark(String name) {
        System.out.println(name + " : Woof");
        return name;
    }
}
