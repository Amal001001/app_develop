package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    String userinput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText text1 = findViewById(R.id.text1);
        Button button = findViewById(R.id.button);
        TextView textView = findViewById(R.id.textView);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                userinput = text1.getText().toString();


                textView.setText(encode(userinput));
                System.out.println(encode(userinput));
                /////////////////////////////////////////////////
            }
        });
    }

    public static char move13(char letter) {
        if ((letter >= 'a' || letter >= 'A') && (letter <= 'm'|| letter <= 'M'))
            return (char) (letter + 13);

        if ((letter >= 'n' || letter >= 'N') && (letter <= 'z'|| letter >= 'Z'))
            return (char) (letter - 13);

        return letter;
    }

    public static String encode(String text) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            char chara = text.charAt(i);
            chara = move13(chara);
            s.append(chara);
        }
        return s.toString();

    }

}