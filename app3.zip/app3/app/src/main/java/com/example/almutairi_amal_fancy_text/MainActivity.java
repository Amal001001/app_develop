package com.example.almutairi_amal_fancy_text;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    String userInput;
    String upperc1 = " ";
    String upperc2 = " ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText text1 = findViewById(R.id.text1);
        Button button = findViewById(R.id.button);
        TextView textView = findViewById(R.id.textView);
        TextView textView2 = findViewById(R.id.textView2);
        TextView textView3 = findViewById(R.id.textView3);
        TextView textView4 = findViewById(R.id.textView4);
        textView3.setText("The same phrase with uppercase" +
                "even letters and lowercase odd" +
                "letters");
        textView4.setText("The same phrase with uppercase" +
                "even letters and lowercase odd" +
                "letters with ignoring spaces" +
                "and special characters");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                userInput = text1.getText().toString();

                char[] chararray = userInput.toCharArray();
                String upperc[] = new String[userInput.length()];

                for (int i = 0; i < userInput.length(); i++) {
                    if (i%2==0){
                        upperc1 += Character.toUpperCase(userInput.charAt(i));}
                        else{
                            upperc1 += Character.toLowerCase(userInput.charAt(i));
                        }

                }
                System.out.println(upperc1);
                ////////////////////////////////////////////////////////////
                int a=0;
                for (int i = 0; i < userInput.length(); i++) {

                    if (Character.isAlphabetic(userInput.charAt(i)) == true) {

                        if (a % 2 == 0) {
                            upperc2 += Character.toUpperCase(userInput.charAt(i));

                        } else {
                            upperc2 += Character.toLowerCase(userInput.charAt(i)); }
                        a= a+1;
                        }

                        else {
                        upperc2 += userInput.charAt(i); }
                }

                System.out.println(upperc2);
                textView.setText(upperc1);
                textView2.setText(upperc2);

            }


        });


    }
}